package com.example.aplicaciondeprueba.netword

import com.example.aplicaciondeprueba.models.AuthResponse
import com.example.aplicaciondeprueba.models.LoginRequest
import com.example.aplicaciondeprueba.models.RegisterResponse
import com.example.aplicaciondeprueba.models.User
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST


interface ApiService {


    @POST("api/auth/login")
    suspend fun login(@Body loginRequest: LoginRequest): Response<AuthResponse>


    @POST("api/auth/register")
    suspend fun register(@Body user: User): Response<RegisterResponse>
}
