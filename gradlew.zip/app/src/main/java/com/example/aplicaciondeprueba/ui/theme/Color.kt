package com.example.aplicaciondeprueba.ui.theme

import androidx.compose.ui.graphics.Color

val PurpleGrey40 = Color(0xFF625B71)
val Pink40 = Color(0xFF7D5260)

val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Primary = Color(0xFF2196F3)
val Success = Color(0xFF4CAF50)       // Verde principal (Éxito)
val SuccessMedium = Color(0xFF81C784) // Verde medio
val SuccessDark = Color(0xFF388E3C)   // Verde oscuro
val TextSecondary = Color(0xFF757575) // Gris para textos secundarios
