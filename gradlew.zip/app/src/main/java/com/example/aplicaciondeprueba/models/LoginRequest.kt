package com.example.aplicaciondeprueba.models

data class LoginRequest(
    val Email: String,
    val PasswoRDkey: String
)
